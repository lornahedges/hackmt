//
//  CardCollectionViewCell.swift
//  matchingGame
//
//  Created by Lorna Hedges on 1/28/23.
//

import UIKit

class CardCollectionViewCell: UICollectionViewCell {
    
}
