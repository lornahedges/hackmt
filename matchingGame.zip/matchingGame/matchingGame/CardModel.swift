//
//  CardModel.swift
//  matchingGame
//
//  Created by Lorna Hedges on 1/28/23.
//

import Foundation

class CardModel {
    func getCards() -> [Card]{
        //declare an array to store the generated cards
        var generatedCardsArray = [Card]()
        
        //randomly generate pairs of cards
        for _ in 1...8 {
            //get a random nuber
            let randomNumber = arc4random_uniform(6) + 1
        
            //log the number
            print(randomNumber)
            
            //generate the first card object
            let cardOne = Card()
            cardOne.imageName = "card\(randomNumber)"
            
            generatedCardsArray.append(cardOne)
            
            //create the second card object
            let cardTwo = Card()
            cardOne.imageName = "card\(randomNumber)"
            
            generatedCardsArray.append(cardTwo)
            
        }
        
        //Randomize the array
   
    
    //return the array
    return generatedCardsArray
    }
}
