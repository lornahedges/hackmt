//
//  ViewController.swift
//  matchingGame
//
//  Created by Lorna Hedges on 1/28/23.
//

import UIKit

class ViewController: UIViewController{
    
    var model = CardModel()
    var cardArray = [Card]()
    override func viewDidLoad(){
        super.viewDidLoad()
        
        //call get cards method of the card model
        cardArray = model.getCards()
    }
    override func didReceiveMemoryWarning(){
        super.didReceiveMemoryWarning()
    }
}
